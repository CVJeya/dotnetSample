module.exports = {
  '/api': {
    target: 'http://localhost:5104',
    secure: false,
    changeOrigin: true,
  }
};
